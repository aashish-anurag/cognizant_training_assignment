package com.stackroute.streams;

public class CountryNotFoundException extends RuntimeException {

}
