package com.stackroute.streams;

public class Batsman {
	
	private String name;
	private Integer matchesPlayed;
	private Integer totalRuns;
	private Integer highestScore;
	private Country country;
	//new Batsman("Virat", 55, 6000, 150, new Country("IN", "India"));
	public Batsman(String name, Integer matchesPlayed , Integer totalRuns   , Integer highestScore, Country country) {
		super();
		this.name = name;
		this.matchesPlayed = matchesPlayed;
		this.totalRuns = totalRuns;
		this.highestScore = highestScore;
		this.country = country;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getMatchesPlayed() {
		return matchesPlayed;
	}
	public void setMatchesPlayed(Integer matchesPlayed) {
		this.matchesPlayed = matchesPlayed;
	}
	public Integer getTotalRuns() {
		return totalRuns;
	}
	public void setTotalRuns(Integer totalRuns) {
		this.totalRuns = totalRuns;
	}
	public Integer getHighestScore() {
		return highestScore;
	}
	public void setHighestScore(Integer highestScore) {
		this.highestScore = highestScore;
	}
	public Country getCountry() {
		return country;
	}
	public void setCountry(Country country) {
		this.country = country;
	}
	public Batsman() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
