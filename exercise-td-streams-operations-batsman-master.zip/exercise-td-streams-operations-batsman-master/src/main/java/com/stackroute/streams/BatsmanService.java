package com.stackroute.streams;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class BatsmanService {

	public Optional<Batsman> getBatsman(List<Batsman> batsmanList, String playerName, String countryCode) throws CountryNotFoundException {
		if(batsmanList==null || countryCode==null) {
			return Optional.empty();
		}
		
		if(batsmanList.stream().map(Batsman::getCountry).distinct().noneMatch(b->b.getCountryCode().equals(countryCode))) {
			throw new CountryNotFoundException();
		}
		return batsmanList.stream().filter(b->b.getName().equalsIgnoreCase(playerName)
				&& b.getCountry().getCountryCode().equals(countryCode)).findFirst();
	
		
	}

	public String getBatsmanNamesForCountry(List<Batsman> batsmanList, String countryCode) {
		if(batsmanList==null || batsmanList.isEmpty()) {
			return null;
		}
		
		return  batsmanList.stream().filter(b->b.getCountry().getCountryCode().equals(countryCode)).map(b->b.getName()).sorted(Comparator.naturalOrder()).collect(Collectors.joining(",","[","]"));
	}

	public Map<String,Integer> getPlayerNameWithTotalRuns(List<Batsman> batsmanList) {
		if(batsmanList==null || batsmanList.isEmpty()) {
			return Collections.emptyMap();
		}
		return batsmanList.stream().collect(Collectors.toMap(b->b.getName(), b->b.getTotalRuns()));
	}

	public Integer getHighestRunsScoredByBatsman(List<Batsman> batsmanList, String countryName) {
		if(batsmanList==null || batsmanList.isEmpty()) {
			return 0;
		}
		return batsmanList.stream().filter(b->b.getCountry().getName().equals(countryName)).map(b->b.getHighestScore()).max(Comparator.naturalOrder()).get();
	}

	public Optional<List<String>> getPlayerNamesByCountry(List<Batsman> batsmanList, String countryName) {
		if(batsmanList==null || batsmanList.isEmpty()) {
			return Optional.empty();
		}
		List<String> result = batsmanList.stream().
				filter(b->b.getCountry().getName().equals(countryName) && b.getTotalRuns()>=5000).
				map(b->b.getName()).
				collect(Collectors.toCollection(LinkedList::new));
		return result.isEmpty()?Optional.empty():Optional.of(result);
	}

}
