package com.microservices.service_one.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/micro1")
public class ControllerServiceOne {

    @GetMapping("/service1")
    public String doWork(){
        return "CALLING MICROSERVICE 1 SERVICE 1";
    }

    @GetMapping("/service2")
    public String doWork2(){
        return "CALLING MICROSERVICE 1 SERVICE 2";
    }
}
