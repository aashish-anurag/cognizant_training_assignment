package com.microservices.service_two.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/micro2")
public class Controllerone {


    @GetMapping("/service1")
    public String doWork(){
        return "CALLING MICROSERVICE 2 SERVICE 1";
    }

    @GetMapping("/service2")
    public String doWork2(){
        return "CALLING MICROSERVICE 2 SERVICE 2";
    }
}
