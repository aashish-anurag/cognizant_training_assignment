package com.stackroute.streams;

public class Batsman {

        private String name;
        private  Integer matchesPlayed;

        private Integer totalRuns;

        private Integer highestScore;

        private Country country;

    public Batsman() {
    }

    public Batsman(String name, Integer matchesPlayed, Integer totalRuns, Integer highestScore, Country country) {
        this.name = name;
        this.matchesPlayed = matchesPlayed;
        this.totalRuns = totalRuns;
        this.highestScore = highestScore;
        this.country = country;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getMatchesPlayed() {
        return matchesPlayed;
    }

    public void setMatchesPlayed(Integer matchesPlayed) {
        this.matchesPlayed = matchesPlayed;
    }

    public Integer getTotalRuns() {
        return totalRuns;
    }

    public void setTotalRuns(Integer totalRuns) {
        this.totalRuns = totalRuns;
    }

    public Integer getHighestScore() {
        return highestScore;
    }

    public void setHighestScore(Integer highestScore) {
        this.highestScore = highestScore;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "Batsman{" +
                "name='" + name + '\'' +
                ", matchesPlayed=" + matchesPlayed +
                ", totalRuns=" + totalRuns +
                ", highestScore=" + highestScore +
                ", country=" + country +
                '}';
    }
}
