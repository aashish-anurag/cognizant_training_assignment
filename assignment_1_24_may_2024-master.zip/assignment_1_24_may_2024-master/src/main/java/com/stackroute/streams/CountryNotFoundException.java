package com.stackroute.streams;

public class CountryNotFoundException extends RuntimeException{

    public CountryNotFoundException(String message){
        super(message);
    }
}
