package com.stackroute.streams;

import java.util.*;
import java.util.stream.Collectors;

public class BatsmanService {

    private BatsmanService batsmanService;

    private List<Batsman> batsmanList;

    private Batsman batsmanVirat;

    private Country countryCode;

    public BatsmanService() {

    }


    /*

    * @apiNote: given service method is to search the list of batsman based on criteria
    * like - 1. Batsman name and country code ignoring case and return with Optional
    *        2. We call RuntimeException if country code does not exist.
    * */

    /**
     *
     * @param batsmanList - list of batsman includes batsman from different country
     * @param batsmanname - name of batsman whose record we need to search
     * @param countryCode - country code for specific country
     * @return  - returns creterias are -1. returns empty if all param are null
     *            2. return the batsman if country code match else through exception
     */
    /*
    public Optional<Batsman> getBatsman(List<Batsman> batsmanList,String batsmanname,String countryCode) {

        if ((batsmanList == null || batsmanList.isEmpty() || (batsmanname == null || batsmanList.isEmpty() || (countryCode == null || countryCode.isEmpty())))) {
            return Optional.empty();
        } else {
            Optional<Batsman> noBatsman = batsmanList.stream().filter(b -> b.getName().equals(batsmanname)).findFirst();
            //  System.out.println("noBatsman= "+noBatsman.get().getName()+" test = "+batsmanname);
            if (noBatsman.isEmpty()) {
                return Optional.empty();
            }
            if (batsmanList.stream().map(Batsman::getCountry).noneMatch(b -> b.getCountryCode().equals(countryCode))) {
                throw new CountryNotFoundException("Country code does not exist");
            }
            return batsmanList.stream().filter(b -> b.getName().equalsIgnoreCase(batsmanname)
                            && b.getCountry().getCountryCode().equalsIgnoreCase(countryCode))
                    .findFirst();

        }
    }
   */
    public Optional<Batsman> getBatsman(List<Batsman> batsmanList, String playerName, String countryCode) throws CountryNotFoundException {
        if(batsmanList==null || countryCode==null) {
            return Optional.empty();
        }

        if(batsmanList.stream().map(Batsman::getCountry).distinct().noneMatch(b->b.getCountryCode().equals(countryCode))) {
            throw new CountryNotFoundException("Country code does not exist !!");
        }
        return batsmanList.stream().filter(b->b.getName().equalsIgnoreCase(playerName)
                && b.getCountry().getCountryCode().equals(countryCode)).findFirst();


    }

    /**
     *
     * @param batsmanList
     * @param countryCode
     * @return  - i. returns null if params are null or empty
     * 2. returns list of batsman comma separated in square bracket
     */
    public String getBatsmanNamesForCountry(List<Batsman> batsmanList,String countryCode) {
        String str = "";
        String emptyNull = null;
        String batsmanNames = null;

        if (batsmanList == null) {
            return emptyNull;
        } else if (batsmanList.isEmpty()) {
            return emptyNull;
        } else {
            if (batsmanList != null && countryCode != null) {
                batsmanNames = batsmanList.stream().filter(b -> b.getCountry().getCountryCode().equals(countryCode)).sorted((b1, b2) -> b1.getName().compareTo(b2.getName())).map(b -> b.getName())
                        .collect(Collectors.joining(","));
                str = str.concat("[").concat(batsmanNames).concat("]");
                return str;
            } else {
                return emptyNull;
            }
        }

    }


    /**
     *
      * @param batsmanList
     * @return - returns map object with name of batsman and total runs
     */
    public Map<String,Integer> getPlayerNameWithTotalRuns(List<Batsman> batsmanList){
        Map<String,Integer> mapOfnameWithTotalRuns = new HashMap<>();
        if(batsmanList == null || batsmanList.isEmpty()) {
            return mapOfnameWithTotalRuns;
        }else{
            mapOfnameWithTotalRuns = batsmanList.stream().filter(b -> b.getMatchesPlayed() > 50).
                    collect(Collectors.toMap(Batsman::getName, Batsman::getTotalRuns));
        }

        return mapOfnameWithTotalRuns;
    }


    /**
     *
     * @param batsmanList
     * @param countryName
     * @return - returns highest score by batsman
     */
    public Integer getHighestRunsScoredByBatsman(List<Batsman> batsmanList, String countryName) {

        Integer highestScore=0;

        if(batsmanList==null){
            return highestScore;
        } else if (batsmanList.isEmpty()) {
            return highestScore;
        }else{
            highestScore = batsmanList.stream().filter(c -> c.getCountry().getName().equals(countryName))
                    .max(Comparator.comparingInt(Batsman::getHighestScore)).get().getHighestScore();
        }

        return highestScore;
    }

    /**
     *
     * @param batsmanList
     * @param countryName
     * @return - 1. returns player list in list format of decending order with total run more than 5k
     * 2. returns instance of LinkedList
     * 3. return empty if total run is not more than 5k
     * 4. return empty in case of empty params
     */
    public Optional<LinkedList<String>> getPlayerNamesByCountry(List<Batsman> batsmanList, String countryName){

        LinkedList<String> playerNameByCountryRunMore50K = new LinkedList<>();
        List<String> playerNameByCountryWithbelow5kRun = new ArrayList<>();

        if(batsmanList == null || batsmanList.isEmpty()){
            return Optional.empty();
        } else if (countryName==null || countryName.isEmpty()) {
            return Optional.empty();
        } else{
            Optional<Batsman> first = batsmanList.stream().filter(bm->bm.getCountry().getName().equals(countryName) && bm.getTotalRuns()>5000)
                    .findFirst();
            if(first.isEmpty()){
                return Optional.empty();
            }else {
                playerNameByCountryRunMore50K = batsmanList.stream().filter(bm->bm.getCountry().getName().equals(countryName) && bm.getTotalRuns()>5000)
                        .map(b->b.getName()).sorted(Collections.reverseOrder()).collect(Collectors.toCollection(LinkedList::new));
                return Optional.of(playerNameByCountryRunMore50K);
            }

        }
    }

}
