package com.cts.spring;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Employee implements InitializingBean, DisposableBean {

	private String ename;

	private String email;

	private Address address;

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [ename=" + ename + ", email=" + email + ", adddress=" + address + "]";
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("Spring container has been closed and i am in destroy() method");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Bean Employee has been instantiated and i am in init() method");
	}
}
