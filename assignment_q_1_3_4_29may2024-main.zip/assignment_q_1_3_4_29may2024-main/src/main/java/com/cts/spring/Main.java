package com.cts.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * =================Assignment 1 , 29 May 2024=============
 * Implement a bean with custom initialization and destruction methods.
 * Define any bean in beans.xml with it respective dependencies
 * Observe the bean lifecycle through console logs.
 */

/**
 * ===========Assignment 3 ,29 May 2024 ============
 *
 * Bean Autowiring :
 * Create a Spring application with two beans: Employee and Address. Use autowiring by name to inject Address into Employee. Configure these beans in XML.
 */
public class Main {
	public static void main(String[] args) {
//assignment 1 , 29 May 2024
		System.out.println("====assignment 1, 29 May 2024==");
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("config.xml");

		Employee employee = (Employee) context.getBean("emp");

		System.out.println(employee);
		context.registerShutdownHook();
		System.out.println("====assignment 3, 29 May 2024==");
//assignment 3, 29 May 2024
		ApplicationContext context2 = new ClassPathXmlApplicationContext("config.xml");
		TextEditor te = (TextEditor) context2.getBean("textEditor");
		te.spellCheck();
		System.out.println("====assignment 4, 29 May 2024====");

//assignment 4, 29 May 2024
// in bean India we have attribute name parent
// where we have define the bean name world means india will have property of World

		World world = (World) context2.getBean("world");
		System.out.println("values in World bean=> "+world.getText1()+" "+world.getText2());
		India india = (India) context2.getBean("india");
        System.out.println("values in India bean=> "+world.getText1()+" "+world.getText2()+" "+india.getText3());

	}
}