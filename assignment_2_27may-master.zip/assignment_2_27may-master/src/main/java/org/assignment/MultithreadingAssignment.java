package org.assignment;

//Multithreading assignments
class Account{
    public int balance;
    public int accountNo;

    void showAccBalance(){
        System.out.println("Account no= "+accountNo+" Balance= "+balance);
    }

    void deposite(int amount){
        balance = balance + amount;
        System.out.println("Deposited = "+ amount);
        showAccBalance();
    }

    void withdraw(int amount){
        balance = balance - amount;
        System.out.println("Withdrawn = "+ amount);
        showAccBalance();
    }

}

class TransactionOfDeposite implements Runnable{

    int amount;
    Account accountX;

    TransactionOfDeposite(Account x,int amount){
        accountX = x;
        this.amount = amount;
        new Thread(this).start();
    }

    @Override
    public void run() {
            accountX.deposite(amount);
    }
}


class TransactionOfWithdraw implements Runnable{
    int amount;
    Account accountY;

    TransactionOfWithdraw(Account y,int amount){
        accountY = y;
        this.amount = amount;
        new Thread(this).start();
    }


    @Override
    public void run() {
        accountY.withdraw(amount);
    }
}


class Account2{
    public int balance;
    public int accountNo;

    void showAccBalance(){
        System.out.println(" Synchronized "+"Account no= "+accountNo+" Balance= "+balance);
    }

    synchronized void deposite(int amount){
        balance = balance + amount;
        System.out.println("Deposited Sync = "+ amount);
        showAccBalance();
    }

    synchronized void withdraw(int amount){
        balance = balance - amount;
        System.out.println("Withdrawn Sync = "+ amount);
        showAccBalance();
    }

}

class TransactionOfDepositeSync implements Runnable{

    int amount;
    Account2 accountX;

    TransactionOfDepositeSync(Account2 x,int amount){
        accountX = x;
        this.amount = amount;
        new Thread(this).start();
    }

    @Override
    public void run() {
        accountX.deposite(amount);
    }
}


class TransactionOfWithdrawSync implements Runnable{
    int amount;
    Account2 accountY;

    TransactionOfWithdrawSync(Account2 y,int amount){
        accountY = y;
        this.amount = amount;
        new Thread(this).start();
    }


    @Override
    public void run() {
        accountY.withdraw(amount);
    }
}

/**
 *
 *
 * Assignment 1: Write a Java program that demonstrates the basic concept of multithreading.
 * Create two threads that print numbers from 1 to 10 concurrently.
 * Ensure proper synchronization to avoid race conditions.
 *
 */

public class MultithreadingAssignment {

    public static void main(String[] args) {

        System.out.println("===== Before synchronized =====");

        Account ac = new Account();
        ac.balance = 10;
        ac.accountNo = 1001;
        TransactionOfDeposite td = new TransactionOfDeposite(ac,500);
        TransactionOfWithdraw tx = new TransactionOfWithdraw(ac,100);

        System.out.println("===== After synchronized =====");


        Account2 ac2 = new Account2();
        ac2.balance = 10;
        ac2.accountNo = 1001;
        TransactionOfDepositeSync td2 = new TransactionOfDepositeSync(ac2,500);
        TransactionOfWithdrawSync tx2 = new TransactionOfWithdrawSync(ac2,100);


    }
}
