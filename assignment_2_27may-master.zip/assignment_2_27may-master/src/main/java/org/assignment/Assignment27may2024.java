package org.assignment;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

record Student(String name,Integer age,Character grade){}
record People(String name,String gender,Integer age){}

public class Assignment27may2024 {
    /**
     * Assignment 1: Filtering and Mapping
     * Write a Java program that uses the Stream API to perform the following tasks on a list of integers:
     * Filter out the even numbers.
     * Square each remaining number.
     * Find the sum of the squared numbers.
     */

    public static int filterEvenNumber(int[] numbers){

        Map<Boolean,List<Integer>> evenOddNumbers = Arrays.stream(numbers).boxed().collect(Collectors.partitioningBy(n -> n % 2 == 0));
        Set<Map.Entry<Boolean, List<Integer>>> entries = evenOddNumbers.entrySet();
        List<Integer> evenNumbers = new ArrayList<>();
        List<Integer> oddNumbers = new ArrayList<>();
        for (Map.Entry<Boolean, List<Integer>> entry : entries) {
            if(Boolean.TRUE.equals(entry.getKey())){
                evenNumbers = entry.getValue();
            }else{
                oddNumbers = entry.getValue();
            }
        }
        //System.out.println("odd="+oddNumbers+" even="+evenNumbers);
       Integer sum = oddNumbers.stream().map(n -> n * n).reduce(0,(integer, integer2) ->integer+integer2 );
        return sum;
    }

    /**
     *
     * Assignment 2: String Manipulation
     * Create a Java program that uses the Stream API to work with a list of strings:
     * Filter out the strings that have a length less than 5.
     * Convert the remaining strings to uppercase.
     * Concatenate all the uppercase strings into a single comma-separated string.
     */

    public static String stringManipulation(String[] str){

        Map<Boolean, List<String>> collect = Arrays.stream(str).collect(Collectors.partitioningBy(s -> s.length() < 5));

        List<String> moreThan5Str = new ArrayList<>();
        List<String> lessThan5Str = new ArrayList<>();
        for (Map.Entry<Boolean, List<String>> booleanListEntry : collect.entrySet()) {
            if(Boolean.TRUE.equals(booleanListEntry.getKey())){
                moreThan5Str = booleanListEntry.getValue();
            }else{
                lessThan5Str = booleanListEntry.getValue();
            }
        }
//        System.out.println(moreThan5Str+" "+lessThan5Str);
        String concatedString = moreThan5Str.stream().map(s -> s.toUpperCase()).collect(Collectors.joining(","));
        return concatedString;
    }

    /**
     *
     *
     Assignment 3: Student Information
     Design a class Student with attributes name, age, and grade. Create a list of students and then use the Stream API to perform the following operations:
     Filter out students who are below 18 years old.
     Sort the remaining students by their grades in ascending order.
     Print the names of the top three students based on their grades.

     */

    public static String getNameOfStudentBasedOnGrades(List<Student> students) {
        List<Student> lessThan18yrs = new ArrayList<>();
        List<Student> moreThan18yrs = new ArrayList<>();
        String topNames = "";
        Map<Boolean, List<Student>> collect = students.stream().collect(Collectors.partitioningBy(s -> s.age() < 18));
        for (Map.Entry<Boolean, List<Student>> booleanListEntry : collect.entrySet()) {
            if (Boolean.TRUE.equals(booleanListEntry.getKey())) {
                lessThan18yrs = booleanListEntry.getValue();
            } else {
                moreThan18yrs = booleanListEntry.getValue();
            }
        }
        List<Student> list = lessThan18yrs.stream().sorted((s1, s2) -> s2.grade().compareTo(s1.grade())).toList();
        topNames = list.stream().map(g -> g.name()).limit(3).collect(Collectors.joining(","));
        // System.out.println(list + " " + topNames);
        return topNames;
    }

    /**
     *
     * Assignment 4: File Processing
     * Write a Java program that reads a text file containing a list of words and uses the Stream API to:
     * Filter out the words that start with the letter 'A'.
     * Count the occurrences of each remaining word.
     * Print the word and its count in descending order of count.
     *
     * @param words
     * @return
     */
    public static Map<String,Long> printWordsCountDecendingOrder(String words){
        List<String> notA = new ArrayList<>();
        List<String> withA = new ArrayList<>();
        Map<Boolean, List<String>> startWithA = Arrays.stream(words.split(" "))
                .collect(Collectors.partitioningBy(w -> w.startsWith("A")));
        for (Map.Entry<Boolean, List<String>> booleanListEntry : startWithA.entrySet()) {
            if (Boolean.TRUE.equals(booleanListEntry.getKey())) {
                withA = booleanListEntry.getValue();
            } else {
                notA = booleanListEntry.getValue();
            }
        }
       // System.out.println(notA+"===="+withA);
        Map<String, Long> collect = notA.stream().collect(Collectors.groupingBy(w -> w, Collectors.counting()))
                .entrySet().stream().sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
                .collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue,(e1,e2)->e2,HashMap::new));

        return collect;
    }

    /**
     * Assignment 5: Data Transformation
     * Create a class Person with attributes name, gender, and age. Given a list of persons, use the Stream API to:
     * Filter out persons with age less than 30.
     * Map the remaining persons to a new list containing only their names.
     * Print the distinct names in alphabetical order.
     * @param
     * @throws IOException
     */

    public static String printDistinctNamesAlphaOrder(List<People> peopleList){

        List<People> lessThan30yrs = new ArrayList<>();
        List<People> moreThan30yrs = new ArrayList<>();
        String topNames = "";
        Map<Boolean, List<People>> collect = peopleList.stream().collect(Collectors.partitioningBy(s -> s.age() < 30));
        for (Map.Entry<Boolean, List<People>> booleanListEntry : collect.entrySet()) {
            if (Boolean.TRUE.equals(booleanListEntry.getKey())) {
                lessThan30yrs = booleanListEntry.getValue();
            } else {
                moreThan30yrs = booleanListEntry.getValue();
            }
            }
        //System.out.println(moreThan30yrs+" "+lessThan30yrs);
        String names = lessThan30yrs.stream().map(p->p.name()).distinct()
                .sorted(Comparator.naturalOrder()).collect(Collectors.joining(" "));
        return names;
    }

    public static void main(String[] args) throws IOException {

        int[] numbers = {2,3,4,5,6,7,8,9};
        Assignment27may2024 mapAndFilter = new Assignment27may2024();
        System.out.println("Filter out even numbers-> \n"+ filterEvenNumber(numbers));

        String[] str = {"Hi","Hello","Welcome","Assignment","Training","end","day2"};
        System.out.println("String Manipulation====> \n"+stringManipulation(str));

        List<Student> studentList = new ArrayList<>();
        studentList = List.of(new Student("Raza",45,'A'),
                new Student("Hasib",45,'A'),
                new Student("Sanjay",17,'B'),
                new Student("Sanjeev",15,'B'),
                new Student("Kamalaa",16,'C'),
                new Student("Rohini",17,'B'));

        System.out.println("Student====> \n"+getNameOfStudentBasedOnGrades(studentList));

        Path path = Path.of("C:\\training\\Assigntest.txt");
        String words = Files.readString(path);
        System.out.println("Read file and print words with count in descending ====> \n"+printWordsCountDecendingOrder(words));
        //printWordsCountDecendingOrder(words);
        List<People> peopleList = new ArrayList<>();
        peopleList = List.of(new People("Raza","Male",40),
                new People("Hasib","Male",29),
                new People("Sanjay","Male",30),
                new People("Sanjeev","Male",32),
                new People("Kamalaa","Female",25),
                new People("Rohini","Female",28));

        System.out.println("printDistinctNamesAlphaOrder====> \n"+printDistinctNamesAlphaOrder(peopleList));
    }

}
