package org.assignment;

class Counter{
    int count=1;
    public void increment(){
         count++;
    }
}

class CounterSync{
    int count=1;
    public synchronized void increment(){
        count++;
    }
}
/**
 * Assignment 2: Develop a multithreaded Java program to simulate a bank account transaction.
 * Create two threads, one for deposit and one for withdrawal. Implement synchronization mechanisms
 * to ensure that deposits and withdrawals do not interfere with each other.
 */

/**
 *
 * without synchonized the increment method the final count value get changed
 * but
 * if we synchonized the increment method then final value of countvalue does not change
 *
 */

public class MultiThread {
    public static void main(String[] args) throws InterruptedException {

        System.out.println("========When Counter is Non-synchronized=========");

        Counter counter = new Counter();

        Runnable runnable1 = ()-> {
            for (int i = 1; i <= 1000; i++) {
                counter.increment();
            }
        };


        Runnable runnable2 = ()-> {
            for (int i = 1; i <= 1000; i++) {
                counter.increment();
            }
        };

        Thread t1 = new Thread(runnable1);
        Thread t2 = new Thread(runnable2);

        t1.start();;
        t2.start();

        t1.join();
        t2.join();

        System.out.println("count without sync => "+counter.count);

        System.out.println("========When Counter is synchronized=========");

        CounterSync counterSync = new CounterSync();

        Runnable runnable3 = ()-> {
            for (int i = 1; i <= 1000; i++) {
                counterSync.increment();
            }
        };


        Runnable runnable4 = ()-> {
            for (int i = 1; i <= 1000; i++) {
                counterSync.increment();
            }
        };

        Thread t3 = new Thread(runnable3);
        Thread t4 = new Thread(runnable4);

        t3.start();;
        t4.start();;

        t3.join();
        t4.join();
        System.out.println("count with sync => "+counterSync.count);
    }
}
