package com.whishlist.whishlist.news.service;

import com.whishlist.whishlist.news.entity.Source;

public interface SourceService {
    Source saveSource(Source source);
}
