package com.whishlist.whishlist.news.repository;

import com.whishlist.whishlist.news.entity.Source;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SourceRepository extends JpaRepository<Source,Long> {

}
