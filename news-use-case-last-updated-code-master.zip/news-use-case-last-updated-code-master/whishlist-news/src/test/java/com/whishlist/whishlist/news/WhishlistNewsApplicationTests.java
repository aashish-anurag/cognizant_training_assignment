package com.whishlist.whishlist.news;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhishlistNewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
