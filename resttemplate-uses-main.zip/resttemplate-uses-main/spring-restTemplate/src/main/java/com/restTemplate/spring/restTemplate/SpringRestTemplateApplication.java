package com.restTemplate.spring.restTemplate;

import com.restTemplate.spring.restTemplate.entity.Employee;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
public class SpringRestTemplateApplication {

	private static final String GET_EMPLOYEE_ENDPOINT_URL = "http://localhost:8080/api/v1/employees/{id}";

	public static void main(String[] args) {

		SpringApplication.run(SpringRestTemplateApplication.class, args);

		SpringRestTemplateApplication application = new SpringRestTemplateApplication();
		application.getEmployeeById();


	}

	private void getEmployeeById() {

		Map<String, String> params = new HashMap< String, String >();
		params.put("id", "1");

		RestTemplate restTemplate = new RestTemplate();
		Employee result = restTemplate.getForObject(GET_EMPLOYEE_ENDPOINT_URL, Employee.class, params);

		System.out.println(result);
	}

}
