package com.lib.management.lib_manage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibManageApplicationTests {

	@Test
	void contextLoads() {
	}

}
