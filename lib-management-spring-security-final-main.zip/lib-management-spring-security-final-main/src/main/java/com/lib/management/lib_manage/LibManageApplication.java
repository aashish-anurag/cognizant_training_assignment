package com.lib.management.lib_manage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibManageApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibManageApplication.class, args);
	}

}
