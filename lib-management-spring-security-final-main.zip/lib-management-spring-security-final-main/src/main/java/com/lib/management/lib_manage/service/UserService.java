package com.lib.management.lib_manage.service;

import com.lib.management.lib_manage.DTOs.UserDto;
import com.lib.management.lib_manage.model.User;

import java.util.List;

public interface UserService {
    void saveUser(UserDto userDto);

    User findByEmail(String email);

    List<UserDto> findAllUsers();
}

