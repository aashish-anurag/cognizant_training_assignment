package com.lib.management.lib_manage.repository;

import com.lib.management.lib_manage.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
    Role findByName(String name);
}
