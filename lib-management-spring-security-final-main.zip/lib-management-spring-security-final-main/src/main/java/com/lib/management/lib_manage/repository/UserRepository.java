package com.lib.management.lib_manage.repository;

import com.lib.management.lib_manage.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
}

