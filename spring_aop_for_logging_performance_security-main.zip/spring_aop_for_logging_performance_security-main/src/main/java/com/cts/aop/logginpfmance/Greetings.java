package com.cts.aop.logginpfmance;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
@Aspect
public class Greetings {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Before("args(name)")
    public void logStringArguments(String name) {
        log.info("String argument passed={}", name);
    }

    @AfterReturning(pointcut = "execution(* *())", returning = "returnString")
    public void getNameReturningAdvice(String returnString) {
        log.info("getNameReturningAdvice executed. Returned String= {}", returnString);
    }

    @Before("execution(* com.cts.aop.Employee.*(*))")
    public void greeting() {
        log.info("Good Morning , What are you doing ? ");
    }

    @After("execution(* com.cts.aop.Employee.*())")
    public void goodbye() {
        log.info("Good Bye!!");
    }

    @Around("execution(* com.cts.aop.Employee.*())")
    public void allMethodTrack(ProceedingJoinPoint joinPoint) throws Throwable {
        String name = joinPoint.getSignature().getName();
        log.info("around called on method===> {}", name);
        Object proceed = joinPoint.proceed();
    }

    @Around("execution(* com.cts.aop.Employee.assignment(*))")
    public void loginAdvice(ProceedingJoinPoint pjp) throws Throwable {
        long start = System.nanoTime();
        Object obj = pjp.proceed();
        long end = System.nanoTime();
        String methodName = pjp.getSignature().getName();

        log.info(methodName + " took " + TimeUnit.NANOSECONDS.toMillis(end - start) + "ms of Execution Time");
    }
}
