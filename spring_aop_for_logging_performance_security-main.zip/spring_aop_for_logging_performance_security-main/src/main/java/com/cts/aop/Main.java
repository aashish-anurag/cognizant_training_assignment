package com.cts.aop;

import com.cts.aop.security.SecurityManager;
import com.cts.aop.logginpfmance.AppConfig;
import com.cts.aop.logginpfmance.Employee;
import com.cts.aop.security.SecureMessage;
import com.cts.aop.security.SecurityAdvice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

    private static Logger log = LoggerFactory.getLogger(Main.class);
    private static SecureMessage getSecureBean() {
        SecureMessage target = new SecureMessage();
        SecurityAdvice advice = new SecurityAdvice();
        ProxyFactory factory = new ProxyFactory();
        factory.setTarget(target);
        factory.addAdvice(advice);
        SecureMessage proxy = (SecureMessage) factory.getProxy();
        return proxy;
    }

    public static void main(String[] args) {
        var container = new AnnotationConfigApplicationContext(AppConfig.class);
        Employee bean = container.getBean(Employee.class);
        bean.login();
        String training = "Spring Boot";
        bean.assignment(training);

        //

        SecurityManager mgr = new SecurityManager();
        SecureMessage beanmsg = getSecureBean();

        mgr.login("Aashish", "pwd");
        log.info("---Scenario 1---");
        beanmsg.writeSecureMessage();
        mgr.logout();
        try {
            mgr.login("invalid user", "pwd");
            log.info("---Scenario 2---");
            beanmsg.writeSecureMessage();
        } catch (SecurityException ex) {
            log.info("Exception Caught: " + ex.getMessage());
        } finally {
            mgr.logout();
        }
        try {
            log.info("---Scenario 3---");
            beanmsg.writeSecureMessage();
        } catch (SecurityException ex) {
            log.info("Exception Caught: " + ex.getMessage());
        }


        //

    }


}
