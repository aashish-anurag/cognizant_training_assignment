package com.cts.aop.logginpfmance;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class Employee {

    private final Logger log = LoggerFactory.getLogger(this.getClass());


    public void assignment(String training) {
        log.info("Busy with training whole day for {}", training);
    }

    public String login() {
        log.info("login job !!");
        return "done!";
    }
}