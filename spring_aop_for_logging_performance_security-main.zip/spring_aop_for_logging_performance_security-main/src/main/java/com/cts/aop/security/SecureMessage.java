package com.cts.aop.security;

public class SecureMessage {
    public void writeSecureMessage() {
        System.out.println("Trying is key to success-Aashish");
    }
}
