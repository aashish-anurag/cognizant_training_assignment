package com.cts.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.cts.dtos.AddressResponse;

@FeignClient(name = "address-service")
public interface AddressFeignClient {

	@GetMapping("/address/{employeeId}")
	public AddressResponse getAddressResponse();
}
