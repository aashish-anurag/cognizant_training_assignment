package com.cts.services;

import java.util.List;

import com.cts.dtos.EmpResponse;

public interface EmpService {

	public EmpResponse getEmpById(Integer id);

}
