package com.cts.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dtos.EmpResponse;
import com.cts.services.EmpService;

@RestController
@RequestMapping("/api/v1/employees")
public class EmployeeController {

	private EmpService service;

	public EmployeeController(EmpService service) {
		this.service = service;
	}

	@GetMapping("/{id}")
	public ResponseEntity<EmpResponse> getEmpById(@PathVariable Integer id) {
		return ResponseEntity.status(HttpStatus.OK).body(service.getEmpById(id));
	}

}
