package com.cts.services;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.cts.dtos.EmpResponse;
import com.cts.entity.EmpEntity;
import com.cts.repository.EmpRepository;

@Service
public class EmpServiceImpl implements EmpService {

	private EmpRepository repository;

	private ModelMapper modelMapper;

	public EmpServiceImpl(EmpRepository repository, ModelMapper modelMapper) {
		this.repository = repository;
		this.modelMapper = modelMapper;
	}

	@Override
	public EmpResponse getEmpById(Integer id) {

		Optional<EmpEntity> optional = repository.findById(id);

		EmpEntity entity = null;

		if (optional.isPresent())
			entity = optional.get();

		EmpResponse empResponse = modelMapper.map(entity, EmpResponse.class);

		return empResponse;
	}

	@Override
	public List<EmpResponse> getEmployees() {
		return null;
	}

}
