package com.cts.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dtos.AddressResponse;
import com.cts.entities.Address;
import com.cts.repository.AddressRepo;

@Service
public class AddressService {
	@Autowired
	private AddressRepo repo;

	@Autowired
	private ModelMapper mapper;

	public AddressResponse findAddressByEmpId(Integer id) {

		Optional<Address> optional = repo.findById(id);

		Address address = null;

		if (optional.isPresent())
			address = optional.get();

		AddressResponse addressResponse = mapper.map(address, AddressResponse.class);

		return addressResponse;
	}
}
