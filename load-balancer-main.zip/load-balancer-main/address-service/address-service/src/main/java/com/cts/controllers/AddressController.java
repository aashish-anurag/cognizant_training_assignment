package com.cts.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dtos.AddressResponse;
import com.cts.service.AddressService;

@RestController
public class AddressController {

	@Autowired
	private AddressService service;

	@GetMapping("/address/{employeeId}")
	public ResponseEntity<AddressResponse> getAddressByEmpId(@PathVariable("employeeId") Integer id) {
		return ResponseEntity.status(200).body(service.findAddressByEmpId(id));
	}
}
