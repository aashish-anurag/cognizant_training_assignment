package org.springcore.learn;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.

/**
 * Load SimpleDateFormat from Spring Configuration XML SimpleDateFormat with
 * the pattern ‘dd/MM/yyyy’ is created in multiple places of an application.
 * To avoid creation of SimpleDateFormat in multiple places, define a bean
 * in Spring XML Configuration file and retrieve the date. Follow steps below to implement:
 *
 * · Create spring configuration file date-format.xml in src/main/resources folder of 'spring-learn' project
 * · Define bean tag in the XML with for date format.
 * · Create new method displayDate() in SpringLearnApplication.java
 * · In displayDate() method create the ApplicationContext. Refer code below:
 * · Get the dateFormat using getBean() method. Refer code below.
 * SimpleDateFormat format = context.getBean(""dateFormat"", SimpleDateFormat.class);
 * · Using the format variable try to parse string '31/05/2022' to Date class and display the result using System.out.println.
 * · Run the application as 'Java Application' and check the result in console log output.
 *
 * Hint:
 * <bean id=""dateFormat"" class=""java.text.SimpleDateFormat"">
 * <constructor-arg value=""dd/MM/yyyy""/>
 * </bean>"
 */
public class Main {
    public static void main(String[] args) throws ParseException {
        ApplicationContext context = new ClassPathXmlApplicationContext("date-format.xml");
        SimpleDateFormat format = context.getBean("dateFormat", SimpleDateFormat.class);
         Date date = format.parse("31/05/2022");
         System.out.println(date);
    }
}
