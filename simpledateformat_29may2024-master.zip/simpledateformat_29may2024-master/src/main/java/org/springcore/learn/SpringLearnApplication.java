package org.springcore.learn;

public class SpringLearnApplication {

private String dateFormat;

    public SpringLearnApplication(String dateFormat) {
        this.dateFormat = dateFormat;
    }
    public String displayDate(){
        return "";
    }
}
