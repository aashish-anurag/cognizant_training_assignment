package com.news.registry.News_registry_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsRegistryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
