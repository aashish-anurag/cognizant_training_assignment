package com.config_server.config_server_assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigServerAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
