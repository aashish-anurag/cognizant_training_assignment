package com.producer.userdetails.producer_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
