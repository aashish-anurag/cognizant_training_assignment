package com.producer.userdetails.producer_user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProducerUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProducerUserApplication.class, args);
	}

}
