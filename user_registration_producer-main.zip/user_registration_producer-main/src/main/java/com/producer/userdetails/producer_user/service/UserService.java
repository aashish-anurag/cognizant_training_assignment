package com.producer.userdetails.producer_user.service;

import com.producer.userdetails.producer_user.entity.User_Info;

public interface UserService {
    User_Info createUser(User_Info user);
}
