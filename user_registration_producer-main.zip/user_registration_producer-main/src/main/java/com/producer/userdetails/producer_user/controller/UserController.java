package com.producer.userdetails.producer_user.controller;

import com.producer.userdetails.producer_user.entity.User_Info;
import com.producer.userdetails.producer_user.service.KafkaSupplierService;
import com.producer.userdetails.producer_user.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/main")
public class UserController {

    private final Logger logger = LoggerFactory.getLogger(UserController.class);

    private final UserService userService;
    private final KafkaSupplierService kafkaSupplierService;

    public UserController(UserService userService, KafkaSupplierService kafkaSupplierService) {
        this.userService = userService;
        this.kafkaSupplierService = kafkaSupplierService;
    }

    @PostMapping("/create-user")
    public ResponseEntity<User_Info> createUser(@RequestBody User_Info user){
        logger.info("====create user======");
        User_Info usr = userService.createUser(user);
        if(usr != null) {
            /*UserDTO udto = new UserDTO();
            udto.setName(usr.getName());
            udto.setEmail(usr.getEmail());
            udto.setPassword(usr.getPassword());
            udto.setAbout(usr.getAbout());*/
            kafkaSupplierService.sendMessage(usr);
        }
        return ResponseEntity.ok(usr);
    }

    @GetMapping("/test")
    public String test(){
        return "Welcome!!";
    }

}
