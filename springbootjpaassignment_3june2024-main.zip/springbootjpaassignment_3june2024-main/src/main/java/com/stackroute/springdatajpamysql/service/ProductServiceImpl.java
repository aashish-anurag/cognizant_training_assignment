package com.stackroute.springdatajpamysql.service;


import com.stackroute.springdatajpamysql.entity.Product;
import com.stackroute.springdatajpamysql.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

//Implement ProductService here
@Service
public class ProductServiceImpl implements ProductService {

    //Override all the methods here

    @Autowired
    private ProductRepo productRepo;

    @Override
    public List<Product> getAllProducts() {

        return productRepo.findAll();
    }

    @Override
    public List<Product> getAllProductsHavingPriceLessThan(double price) {
        return (List<Product>) productRepo.findProductsLessThanPrice(price);
    }

    @Override
    public Product getProductById(Long prodcutId) {

        return productRepo.findById(prodcutId).get();
    }

    @Override
    public Product saveProduct(Product product) {

        return productRepo.save(product);
    }

    @Override
    public Product updateProduct(Product product,Long productId) {
        Optional<Product> existingProduct = productRepo.findById(productId);
        Product product1 = null;
        if(existingProduct.isPresent()){
            product1 = existingProduct.get();
            product1.setId(product.getId());
            product1.setName(product.getName());
            product1.setPrice(product.getPrice());
        }

        return productRepo.save(product1);
    }

    @Override
    public String deleteProduct(Long productId) {
        productRepo.deleteById(productId);
        return "Product Deleted";
    }

}
