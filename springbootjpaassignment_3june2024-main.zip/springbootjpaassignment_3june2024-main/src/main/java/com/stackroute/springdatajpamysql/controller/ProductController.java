package com.stackroute.springdatajpamysql.controller;

import com.stackroute.springdatajpamysql.entity.Product;
import com.stackroute.springdatajpamysql.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductController {
    // Add controllers here for CRUD operations on Product entity.
    @Autowired
    private ProductService productService;

    @GetMapping("/products")
    public ResponseEntity<List<Product>> getAllProducts(){
        List<Product> products=productService.getAllProducts();
        return new ResponseEntity<>(products, HttpStatus.OK);
    }
    @GetMapping("/products/{price}")
    public ResponseEntity<List<Product>> getAllProductsHavingPriceLessThan(@PathVariable Double price){
        return ResponseEntity.ok(productService.getAllProductsHavingPriceLessThan(price));
    }

    @GetMapping(" /products/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id){
        return ResponseEntity.ok(productService.getProductById(id));
    }


    @PostMapping("/products")
    public ResponseEntity<Product> saveProduct(@RequestBody Product product){
        return ResponseEntity.ok(productService.saveProduct(product));
    }


    @PutMapping("products/{id}")
    public ResponseEntity<?> updateProduct(Product updatedProduct, Long productId) {
        return ResponseEntity.ok(productService.updateProduct(updatedProduct, productId));
    }

    @DeleteMapping("/products/{id}")
    public ResponseEntity<?> deleteProduct(Long productId) {
        productService.deleteProduct(productId);
        return ResponseEntity.ok("Product Deleted");
    }
}
