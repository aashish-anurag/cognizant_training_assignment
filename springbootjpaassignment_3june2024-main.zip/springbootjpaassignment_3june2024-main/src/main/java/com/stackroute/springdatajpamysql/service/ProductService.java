package com.stackroute.springdatajpamysql.service;

import com.stackroute.springdatajpamysql.entity.Product;

import java.util.List;

//Create service interface here
public interface ProductService {
    //Add abstract methods here
    public List<Product> getAllProducts();
    public List<Product> getAllProductsHavingPriceLessThan(double price);
    public Product getProductById(Long prodcutId);
    public Product saveProduct(Product product);
    public Product updateProduct(Product product,Long productId);
    public String deleteProduct(Long productId);



}
