package com.cts.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "consumer-service", url="http://localhost:9091/")
public interface UserFeignConsumer {

	@GetMapping("/users")
	public String getUsers();

}
