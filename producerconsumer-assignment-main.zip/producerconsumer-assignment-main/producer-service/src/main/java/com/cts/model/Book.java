package com.cts.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Book {
	private Integer bid;
	private String bname;
	private String author;

	public Book(Integer bid, String bname, String author) {
		this.bid = bid;
		this.bname = bname;
		this.author = author;
	}
}
