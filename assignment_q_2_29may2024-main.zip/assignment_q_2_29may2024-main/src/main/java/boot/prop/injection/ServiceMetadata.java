package boot.prop.injection;

import org.springframework.beans.factory.annotation.Value;

public class ServiceMetadata {

    @Value("${service.app}")
    private String appName;
    @Value("${service.port}")
    private Integer port;
    @Value("${service.server}")
    private String server;

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    @Override
    public String toString() {
        return "ServiceMetadata{" +
                "appName='" + appName + '\'' +
                ", port=" + port +
                ", server='" + server + '\'' +
                '}';
    }
}
