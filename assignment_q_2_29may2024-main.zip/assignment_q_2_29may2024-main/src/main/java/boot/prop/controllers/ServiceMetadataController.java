package boot.prop.controllers;

import boot.prop.injection.ServiceMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceMetadataController {

    @Autowired
    private ServiceMetadata serviceMetadata;

    @GetMapping("/service")
    public String getServiceDetail(){
        return ""+serviceMetadata.getAppName()+" "+serviceMetadata.getServer()+
                " "+serviceMetadata.getPort();
    }
}
