package com.assignment.boot.boot.concepts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootConceptsApplicationTests {

	@Test
	void contextLoads() {
	}

}
