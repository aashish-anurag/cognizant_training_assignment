package com.whishlist.whishlist.news.service;

import com.whishlist.whishlist.news.entity.Article;

public interface ArticleService {
    Article saveArtcle(Article article);
}
