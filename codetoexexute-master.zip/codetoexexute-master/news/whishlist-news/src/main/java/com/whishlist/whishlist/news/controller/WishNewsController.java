package com.whishlist.whishlist.news.controller;

import com.whishlist.whishlist.news.dto.NewsResponse;
import com.whishlist.whishlist.news.dto.TopHeadlinesRequestDto;
import com.whishlist.whishlist.news.entity.Article;
import com.whishlist.whishlist.news.feignclient.ToHeadlines;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/wishlist")
public class WishNewsController {

    @Autowired
    private ToHeadlines headlines;

    @GetMapping(value = "/getHeadline")
    public ResponseEntity<?> getHeadline(@RequestParam(value="country",required = false) String country,
                                                    @RequestParam(value="category",required = false) String category,
                                                    @RequestParam(value="sources",required = false) String sources,
                                                    @RequestParam(value="q",required = false) String q,
                                                    @RequestParam(value="pageSize",defaultValue = "20") String pageSize,
                                                    @RequestParam(value="page",defaultValue = "1") String page
                                                    ) throws URISyntaxException {
        //@RequestHeader("X-Api-Key") String apiKey

       // final String query = "country=de&category=business&apiKey=8609e40133f04c23a7b08501c28a7a3e";
        System.out.println("Parameters=======>"+country+" "+category+" "+sources+" "+q+" ");
       // System.out.println(toHeadlines.getTopHeadlinesBrakingNews(dto, pageSize, page));

        var query = "country="+country+"&category="+category+"&sources="+sources+"&pageSize="+pageSize+"&page="+page+"";

//        return ResponseEntity.ok(headlines.getHeadline(country,category,sources,q, pageSize, page,apiKey));

        RestTemplate restTemplate = new RestTemplate();
        URI uri = new URI("http://localhost:8011/news/topheadlines"+query);
        System.out.println("======="+uri.toString());
        Article[] forEntity = restTemplate.getForEntity(uri.toString(), Article[].class).getBody();
        System.out.println("forEnitity===="+forEntity);
        return new ResponseEntity(forEntity,HttpStatus.OK);


    }

    
}
