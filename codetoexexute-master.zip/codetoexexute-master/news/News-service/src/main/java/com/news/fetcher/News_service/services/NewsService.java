package com.news.fetcher.News_service.services;

public interface NewsService {
}
