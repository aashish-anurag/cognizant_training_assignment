package com.news.fetcher.News_service.repository;

public class NewsRepository {
}
