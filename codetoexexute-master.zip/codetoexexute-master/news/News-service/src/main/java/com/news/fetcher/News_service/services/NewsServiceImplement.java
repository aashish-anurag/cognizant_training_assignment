package com.news.fetcher.News_service.services;

public class NewsServiceImplement implements NewsService{
}
