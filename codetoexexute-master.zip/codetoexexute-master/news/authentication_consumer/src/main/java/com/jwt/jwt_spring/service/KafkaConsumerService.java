package com.jwt.jwt_spring.service;

import com.jwt.jwt_spring.DTOs.UserDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumerService {
    private Logger log = LoggerFactory.getLogger(KafkaConsumerService.class);

    @KafkaListener(topics = "NewsTopic",groupId = "Group100",containerFactory = "kafkaConListener")
    public void listen(UserDto userDTO){
        log.info("Received {}",userDTO," from the Topic NewsTopic");
    }
}
