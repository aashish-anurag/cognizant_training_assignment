package com.example.producer.to.kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerToKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
