package com.example.producer.to.kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class KafkaObjectProducer {

    private final KafkaTemplate<String, Book> kafkaTemplate;

    public void sendMessage(Book book){
        Message<Book> topic1 = MessageBuilder.withPayload(book)
                .setHeader(KafkaHeaders.TOPIC, "Topic1")
                .build();
        kafkaTemplate.send(topic1);
    }

}
