package com.example.producer.to.kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProducerToKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProducerToKafkaApplication.class, args);
	}

}
